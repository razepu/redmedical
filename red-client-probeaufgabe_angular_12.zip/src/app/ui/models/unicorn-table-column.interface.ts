export type IUnicornTableColumn = 'number' | 'resourceType' | 'name' | 'gender' | 'birthDate';
