import { TestBed } from '@angular/core/testing';

/**
 * Optionale Zusatzaufgabe
 */
describe('SearchFacadeService', () => {
  beforeEach(async () => {
    TestBed.configureTestingModule({
      imports: [],
      providers: [],
    });
  });
  // tslint:disable:no-empty
  test('should init', () => {});

  test('should find patients', () => {});

  test('should find practitioners', () => {});

  test('should find both', () => {});

  test('merge arrays', () => {});
});
