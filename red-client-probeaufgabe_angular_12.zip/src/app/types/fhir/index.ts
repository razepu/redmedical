export * from './link.interface';
export * from './fhir-resource.interface';
export * from './patient.interface';
export * from './practitioner.interface';
export * from './prepared-fhir-data.interface';
