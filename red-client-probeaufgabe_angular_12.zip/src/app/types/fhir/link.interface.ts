export interface ILink {
  label: string;
  href: string;
  icon?: string;
}
