export enum FhirResourceType {
  Patient = 'Patient',
  Practitioner = 'Practitioner',
}
