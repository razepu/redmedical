export enum FhirSearchFn {
  SearchPatients = 'searchPatients',
  SearchPractitioners = 'searchPractitioners',
  SearchAll = 'searchAll',
}
